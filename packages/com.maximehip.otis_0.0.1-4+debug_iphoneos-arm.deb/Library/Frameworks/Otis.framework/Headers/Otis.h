// HEADER FOR OTIS

#include <UIKit/UIKit.h>

@interface Otis : NSObject

-(void)Otis_update:(NSString *)tweakName fileServer:(NSString *)fileServer;

@end